-- phpMyAdmin SQL Dump
-- version 4.4.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 10, 2016 at 04:05 PM
-- Server version: 5.6.25
-- PHP Version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `web_logickehry_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `game_type`
--

CREATE TABLE IF NOT EXISTS `game_type` (
  `game_type_id` int(11) NOT NULL,
  `game_name` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `game_subtitle` varchar(60) COLLATE utf8_bin DEFAULT NULL,
  `avg_playtime` int(11) DEFAULT NULL,
  `min_players` tinyint(3) unsigned NOT NULL,
  `max_players` tinyint(3) unsigned DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `game_type`
--

INSERT INTO `game_type` (`game_type_id`, `game_name`, `game_subtitle`, `avg_playtime`, `min_players`, `max_players`) VALUES
(1, 'Abalone', 'Quattro', 30, 2, 4),
(2, 'Afrika', '', 60, 2, 4),
(3, 'Agricola', NULL, 120, 1, 5),
(4, 'Alcatraz', 'Jumbo', 30, 1, 1),
(5, 'Alhambra', NULL, 60, 2, 6),
(6, 'Alchymisté', '', 90, 2, 4),
(7, 'Anti Virus', 'Smart', 20, 1, 1),
(8, 'Bang!', '', 30, 4, 7),
(9, 'Beasty Bar', 'New beasts in town', 20, 2, 4),
(10, 'Callisto', '', 30, 2, 4),
(11, 'ColorPop', '', 15, 1, 5),
(12, 'Colt Express', '', 30, 2, 6),
(13, 'Černé historky', 'Absurdní příběhy', 40, 2, 15),
(14, 'Dixit', '', 30, 3, 6),
(15, 'Duch!', '', 20, 2, 8),
(16, 'Fresco', '', 45, 2, 4),
(17, 'Galaxy Trucker', '', 60, 2, 4),
(18, 'Genial', 'Spezial', 40, 2, 4),
(19, 'Gyges', '', 15, 2, 2),
(20, 'Hive Pocket', '', 20, 2, 2),
(21, 'Chňapni čuníka!', '', 15, 1, 5),
(22, 'Koncept', '', 40, 4, 12),
(23, 'Milostný dopis', '', 15, 2, 4),
(24, 'Minutová říše', '', 8, 2, 4),
(25, 'Nox', '', 20, 2, 6),
(26, 'Port Royal', '', 20, 2, 5),
(27, 'Pylos', 'mini', 10, 2, 2),
(28, 'RoboRally', '', 120, 2, 8),
(29, 'Timeline', 'Pestrá historie', 15, 2, 8),
(30, 'Tokaido', '', 45, 2, 5),
(31, 'Jenga', 'Barevná věž', 20, 2, 8),
(32, 'Vládce Tokia', '', 30, 2, 6),
(33, 'Záchranáři', 'Boj s ohněm', 45, 1, 6),
(34, 'Zeměplocha', 'Ankh-Morpork', 60, 2, 4),
(35, 'Šachy', '', 60, 2, 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `game_type`
--
ALTER TABLE `game_type`
  ADD PRIMARY KEY (`game_type_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `game_type`
--
ALTER TABLE `game_type`
  MODIFY `game_type_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=36;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
